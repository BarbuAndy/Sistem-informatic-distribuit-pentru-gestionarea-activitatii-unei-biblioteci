﻿namespace WebApplication.context
{
    public class Stock
    {
       public int StockId { get; set; }
       public Book Book { get; set; }
       public Branch Branch { get; set; }
       public uint NumberOfAdded { get; set; }

    }
}