﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication.context
{
    public class Library
    {
        public int LibraryId { get; set; }
        public string Name { get; set; }

    }
}
