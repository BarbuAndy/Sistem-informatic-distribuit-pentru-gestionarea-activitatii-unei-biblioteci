﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication.context
{
    public class Borrow
    {
        public int BorrowId { get;set; }

        [Required]
        public User User { get; set; }
        [Required]
        public Branch Branch { get; set; }
        public IEnumerable<Book> BookList { get; set; }
        public DateTime DueDate { get; set; }
        
        public bool IsLate { get; set; }
    }
}
