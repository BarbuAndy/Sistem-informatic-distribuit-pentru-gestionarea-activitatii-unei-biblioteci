﻿using System;
using System.Collections.Generic;

namespace WebApplication.context
{
    public class Author
    {
        public int AuthorId { get; set; }
        public string Name { get; set; }
        public DateTime Birth_year { get; set; }
        public bool Deceased { get; set; }

        public IEnumerable<Book> BookList { get; set; }
    }
}