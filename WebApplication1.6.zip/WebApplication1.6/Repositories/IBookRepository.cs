﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.context;

namespace WebApplication.Repositories
{
    public interface IBookRepository : IRepositoryBase<Book>
    {
        
    }
}
