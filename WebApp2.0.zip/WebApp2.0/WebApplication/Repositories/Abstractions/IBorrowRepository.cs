﻿using Olympia_Library.Data;

namespace WebApplication.Repositories
{
    public interface IBorrowRepository : IRepositoryBase<Borrow>
    {
    }
}