﻿using Olympia_Library.Data;


namespace WebApplication.Repositories.Reps
{
    public interface IBranchRepository : IRepositoryBase<Branch>
    {
    }
}