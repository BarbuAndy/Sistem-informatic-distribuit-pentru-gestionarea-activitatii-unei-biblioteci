﻿using Olympia_Library.Data;

namespace WebApplication.Repositories
{
    public interface IGenreRepository : IRepositoryBase<Genre>
    {
    }
}