﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication.Models
{
    public class AuthorModel
    {
        public string Name { get; set; }
        public int Birth_year { get; set; }
        public bool Deceased { get; set; }
    }
}
