﻿namespace Olympia_Library.Data
{
    public class Author
    {
        public int AuthorId { get; set; }
        public string Name { get; set; }
        public int Birth_year { get; set; }
        public bool Deceased { get; set; }
    }
}